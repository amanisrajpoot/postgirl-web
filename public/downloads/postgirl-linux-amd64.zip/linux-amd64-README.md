# Postgirl - linux/amd64

## Quick Start

### Interactive Menu (Default)
```bash
./postgirl-linux-amd64
```
- Interactive menu to choose interface
- Auto-opens browser for web interface
- No external dependencies
- **No security warnings on macOS!**

### Direct Launch
```bash
# Web Interface (auto-opens browser)
./postgirl-linux-amd64 web

# Terminal Interface
./postgirl-linux-amd64 tui
```

## Features
- 🌐 Modern Web Interface
- 💻 Terminal Interface (TUI)
- 🔐 Multiple Authentication Methods
- 📝 Request/Response History
- 📂 Collections & Environments
- 🔧 JavaScript Scripting
- 🚀 Cross-platform (macOS, Linux, Windows)
- 🔒 **Code signed (macOS) - No security warnings!**

## Support
- Web Interface: http://localhost:8080
- Terminal Interface: Keyboard navigation
- No installation required - just run!

## Files
- `postgirl-linux-amd64` - Postgirl executable (signed and ready to run)
- `linux-amd64-README.md` - This file

