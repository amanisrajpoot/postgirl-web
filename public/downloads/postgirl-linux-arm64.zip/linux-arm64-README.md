# Postgirl - linux/arm64

## Quick Start

### Interactive Menu (Default)
```bash
./postgirl-linux-arm64
```
- Interactive menu to choose interface
- Auto-opens browser for web interface
- No external dependencies

### Direct Launch
```bash
# Web Interface (auto-opens browser)
./postgirl-linux-arm64 web

# Terminal Interface
./postgirl-linux-arm64 tui
```

## Features
- 🌐 Modern Web Interface
- 💻 Terminal Interface (TUI)
- 🔐 Multiple Authentication Methods
- 📁 Collections & Environments
- 📝 Request/Response History
- 🔧 JavaScript Scripting
- 🚀 Cross-platform Support

## Support
- Web Interface: http://localhost:8080
- Terminal Interface: Keyboard navigation
- No installation required - just run!

## Files
- `postgirl-linux-arm64` - Postgirl executable (with interactive menu)
- `linux-arm64-README.md` - This file

