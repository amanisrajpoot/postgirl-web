# Postgirl - windows/arm64

## Quick Start

### Interactive Menu (Default)
```bash
./postgirl-windows-arm64.exe
```
- Interactive menu to choose interface
- Auto-opens browser for web interface
- No external dependencies
- **No security warnings on macOS!**

### Direct Launch
```bash
# Web Interface (auto-opens browser)
./postgirl-windows-arm64.exe web

# Terminal Interface
./postgirl-windows-arm64.exe tui
```

## Features
- 🌐 Modern Web Interface
- 💻 Terminal Interface (TUI)
- 🔐 Multiple Authentication Methods
- 📝 Request/Response History
- 📂 Collections & Environments
- 🔧 JavaScript Scripting
- 🚀 Cross-platform (macOS, Linux, Windows)
- 🔒 **Code signed (macOS) - No security warnings!**

## Support
- Web Interface: http://localhost:8080
- Terminal Interface: Keyboard navigation
- No installation required - just run!

## Files
- `postgirl-windows-arm64.exe` - Postgirl executable (signed and ready to run)
- `windows-arm64-README.md` - This file

