# Postgirl - windows/amd64

## Quick Start

### Interactive Menu (Default)
```bash
./postgirl-windows-amd64.exe
```
- Interactive menu to choose interface
- Auto-opens browser for web interface
- No external dependencies

### Direct Launch
```bash
# Web Interface (auto-opens browser)
./postgirl-windows-amd64.exe web

# Terminal Interface
./postgirl-windows-amd64.exe tui
```

## Features
- 🌐 Modern Web Interface
- 💻 Terminal Interface (TUI)
- 🔐 Multiple Authentication Methods
- 📁 Collections & Environments
- 📝 Request/Response History
- 🔧 JavaScript Scripting
- 🚀 Cross-platform Support

## Support
- Web Interface: http://localhost:8080
- Terminal Interface: Keyboard navigation
- No installation required - just run!

## Files
- `postgirl-windows-amd64.exe` - Postgirl executable (with interactive menu)
- `windows-amd64-README.md` - This file

